package com.project.productsvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
