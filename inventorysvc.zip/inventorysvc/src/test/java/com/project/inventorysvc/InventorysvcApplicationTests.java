package com.project.inventorysvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventorysvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
